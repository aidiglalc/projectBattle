
// This Class is just only for tests

public class Main {
    public static void main(String[] args) {
          new Window(); // Creates the main window
//        System.out.println(new Character().getRace("Human")); // Prints an ArrayList of the Humans with their stats
//        System.out.println(new Character().getRace("Elf"));   // Prints an ArrayList of the Elves with their stats
//        System.out.println(new Character().getRace("Dwarf")); // Prints an ArrayList of the Dwarves with their stats
//        System.out.println(new Weapon().getWeapons("Human")); // Prints an ArrayList of the weapons equippable by Humans with their stats
//        System.out.println(new Weapon().getWeapons("Elf"));   // Prints an ArrayList of the weapons equippable by Elves with their stats
//        System.out.println(new Weapon().getWeapons("Dwarf")); // Prints an ArrayList of the weapons equippable by Dwarfs with their stats
//        System.out.println(new Weapon().getWeapons(""));      // Prints an ArrayList of all weapons with their stats


//        Method to see the fonts available in the OS

//        System.out.println(Frame.getFrames());
//        String[] nombreFuentes = GraphicsEnvironment.getLocalGraphicsEnvironment()
//                .getAvailableFontFamilyNames();
//
//        System.out.println("Nombre de las fuentes disponibles");
//        System.out.println(Arrays.toString(nombreFuentes));
//
//        System.out.println("\nFuentes disponibles");
//        Font[] fuentes = GraphicsEnvironment.getLocalGraphicsEnvironment().getAllFonts();
//        for (Font f : fuentes) {
//            System.out.println(f.getName());
//        }
    }
}